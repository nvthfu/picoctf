/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const process: (a: number, b: number, c: any) => number;
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_start: () => void;
